extern void iwasm_main();
int main(int argc, char *argv[])
{
    iwasm_main(argc, argv);
}
