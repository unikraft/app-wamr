
# WebAssembly Micro Runtime Roadmap


## Ahead of time compilation
Status: under development. The first release is targetted to the end of 2019.

## WASI support
Evaluated solution.

## Data serialization
Evauating using cbor as the default data serialization

## Threading
Not started yet

