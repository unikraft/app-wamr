/* ARP has been moved to core/ipv4, provide this #include for compatibility only */
#include "lwip/etharp.h"
#include "netif/ethernet.h"
